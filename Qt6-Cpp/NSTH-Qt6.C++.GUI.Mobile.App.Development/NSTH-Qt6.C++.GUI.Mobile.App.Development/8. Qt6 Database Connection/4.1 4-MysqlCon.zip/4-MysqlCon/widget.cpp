#include "widget.h"
#include "./ui_widget.h"
#include<QSqlDatabase>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setUserName("root");
    db.setPassword("");
    db.setDatabaseName("qt6");

    if(!db.open()) {
        ui->label->setText("Database is not connected");

    }else {
        ui->label->setText("Database is Connected");
    }

}

