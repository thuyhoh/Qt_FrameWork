#include "widget.h"
#include "./ui_widget.h"
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QMessageBox>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/Users/parwiz/Downloads/database.sqlite");
    if(!db.open()) {
        QMessageBox::information(this, "Databas error", "Database is not connected");

    } else {
        QSqlQuery query;
        QString firstname = ui->lineEditFirst->text();
        QString lastname = ui->lineEditLast->text();
        QString age = ui->lineEditAge->text();

        query.exec("INSERT INTO users (firstname, lastname, age) VALUES ('" + firstname + "','" + lastname + "'," + age + ")");
        QMessageBox::information(this, "Databas added", "Data added to database");

        ui->lineEditFirst->setText("");
        ui->lineEditLast->setText("");
        ui->lineEditAge->setText("");

    }

}

